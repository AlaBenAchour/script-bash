autoload -Uz compinit && compinit

# Plugins Oh My Zsh
plugins=(git zsh-completions)
